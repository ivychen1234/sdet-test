import { test, expect } from '@playwright/test';

// 設定較長的測試超時時間
test.setTimeout(180000);

test.use({
    viewport: { width: 1366, height: 768 },
    deviceScaleFactor: 1,
    isMobile: false,
    hasTouch: false,
    permissions: ['camera', 'microphone'],
    userAgent: 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/136.0.0.0 Safari/537.36 HTCVRSDET',
    launchOptions: {
        args: [
            '--use-fake-ui-for-media-stream',
            '--use-fake-device-for-media-stream',
            '--enable-webgl',
            '--disable-web-security',
            '--window-size=1366,768',
            '--allow-forms',
            '--allow-modals',
            '--allow-orientation-lock',
            '--allow-pointer-lock',
            '--allow-popups',
            '--allow-popups-to-escape-sandbox',
            '--allow-presentation',
            '--allow-same-origin',
            '--allow-scripts',
            '--allow-top-navigation',
            '--allow-top-navigation-by-user-activation'
        ],
        headless: false
    }
});

test.describe('Unity Game Test', () => {
    test('should load and interact with Unity game', async ({ page }) => {
        // 設置瀏覽器特徵
        await page.addInitScript(() => {
            Object.defineProperty(navigator, 'platform', { get: () => 'MacIntel' });
            Object.defineProperty(navigator, 'vendor', { get: () => 'Apple Computer, Inc.' });
            Object.defineProperty(navigator, 'appVersion', { 
                get: () => '5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/136.0.0.0 Safari/537.36'
            });
            Object.defineProperty(navigator, 'appName', { get: () => 'Netscape' });
            Object.defineProperty(navigator, 'appCodeName', { get: () => 'Mozilla' });
        });

        // 設置 Unity 遊戲所需的權限
        await page.addInitScript(() => {
            // 設置 iframe 的 sandbox 屬性
            const setUnityGamePermissions = () => {
                const iframes = document.querySelectorAll('iframe');
                iframes.forEach(iframe => {
                    if (iframe.src.includes('unity')) {
                        iframe.setAttribute('sandbox', 'allow-forms allow-modals allow-orientation-lock allow-pointer-lock allow-popups allow-popups-to-escape-sandbox allow-presentation allow-same-origin allow-scripts allow-top-navigation allow-top-navigation-by-user-activation');
                    }
                });
            };

            // 監聽 DOM 變化，確保動態加載的 iframe 也能獲得權限
            const observer = new MutationObserver((mutations) => {
                mutations.forEach((mutation) => {
                    if (mutation.addedNodes.length) {
                        setUnityGamePermissions();
                    }
                });
            });

            observer.observe(document.body, {
                childList: true,
                subtree: true
            });

            // 初始設置
            setUnityGamePermissions();
        });

        // 授予必要的權限
        await page.context().grantPermissions(['camera', 'microphone']);

        // 檢查設備設置
        const deviceInfo = await page.evaluate(() => {
            const check = (obj: any, prop: string) => {
                try {
                    return prop in obj;
                } catch (e) {
                    return false;
                }
            };

            return {
                userAgent: navigator.userAgent,
                webgl: !!document.createElement('canvas').getContext('webgl'),
                webgl2: !!document.createElement('canvas').getContext('webgl2'),
                webxr: check(navigator, 'xr'),
                mediaDevices: check(navigator, 'mediaDevices'),
                getUserMedia: check(navigator.mediaDevices, 'getUserMedia'),
                permissions: check(navigator, 'permissions'),
                hardwareConcurrency: navigator.hardwareConcurrency || 'unknown'
            };
        });
        console.log('Device Info:', JSON.stringify(deviceInfo, null, 2));

        // Step 1: Navigate to the Unity game page
        await page.goto('https://worlds.viverse.com', {
            waitUntil: 'domcontentloaded'
        });
        console.log('Step 1: Navigated to Viverse website');

        // Step 2: Sign in
        const signInButton = page.locator('nav button:has-text("Sign In")').first();
        await signInButton.waitFor({ state: 'visible', timeout: 30000 });
        await signInButton.click();
        console.log('Step 2: Clicked Sign In button');

        // 等待轉導到登入頁面
        await page.waitForURL(/https:\/\/account\.htcvive\.com\/login\/saml/, { timeout: 60000 });
        await page.waitForLoadState('domcontentloaded');
        console.log('Redirected to login page');

        // Step 3: Fill in credentials
        const emailInput = page.locator('input[type="text"], input[type="email"]').first();
        await emailInput.waitFor({ state: 'visible', timeout: 30000 });
        await emailInput.fill('ivy_chen@htc.com');
        console.log('Step 3: Filled in email');

        const passwordInput = page.locator('input[type="password"]').first();
        await passwordInput.waitFor({ state: 'visible', timeout: 30000 });
        await passwordInput.fill('1234567A');
        console.log('Step 3: Filled in password');
        
        const submitButton = page.getByRole('button', { name: 'Sign In' });
        await submitButton.waitFor({ state: 'visible', timeout: 30000 });
        await submitButton.click();
        console.log('Step 3: Clicked Sign In button');

        // Wait for login to complete
        try {
            await page.waitForURL('https://worlds.viverse.com/', { timeout: 60000 });
            await page.waitForLoadState('domcontentloaded');
            await page.waitForLoadState('networkidle', { timeout: 60000 });
            console.log('Login completed');
        } catch (error) {
            console.log('Login redirect timeout, but continuing:', error);
        }

        // Step 4: Navigate to Unity game room
        await page.goto('https://create.viverse.com/UnityGameRoom', {
            waitUntil: 'domcontentloaded'
        });
        console.log('Step 4: Navigated to Unity game room');

        // 等待頁面加載
        console.log('等待頁面加載...');
        try {
            await page.waitForLoadState('domcontentloaded', { timeout: 30000 });
            console.log('DOM 內容加載完成');
            
            await page.waitForLoadState('load', { timeout: 30000 });
            console.log('主要資源加載完成');
        } catch (error) {
            console.log('頁面加載超時，但繼續執行:', error);
        }

        // 等待 Unity 遊戲加載
        console.log('等待 Unity 遊戲加載...');
        await page.waitForTimeout(15000);
        console.log('Unity 遊戲應該已加載完成');

        // Step 5: 檢查 Unity 遊戲是否正確加載
        const unityCanvas = page.locator('#unity-canvas');
        await unityCanvas.waitFor({ state: 'visible', timeout: 30000 });
        console.log('Unity canvas is visible');

        // 等待 Unity 遊戲初始化
        await page.waitForTimeout(5000);

        // Step 6: 測試遊戲場景
        console.log('測試遊戲場景');
        
        // 檢查背景是否正確加載
        const skyboxCheck = await page.evaluate(() => {
            const canvas = document.querySelector('#unity-canvas');
            if (!canvas) return false;
            
            // 獲取 canvas 的背景顏色
            const style = window.getComputedStyle(canvas);
            const backgroundColor = style.backgroundColor;
            
            // 檢查是否為藍色系
            return backgroundColor.includes('rgb(135, 206, 235)') || // 天藍色
                   backgroundColor.includes('rgb(0, 191, 255)') ||   // 深天藍
                   backgroundColor.includes('rgb(173, 216, 230)');   // 淺藍色
        });
        console.log('Skybox loaded:', skyboxCheck);

        // Step 7: 測試平台跳躍
        console.log('測試平台跳躍');
        
        // 模擬跳躍動作
        const jumpSequence = async () => {
            // 跳躍到第一個平台
            await page.keyboard.press('Space');
            await page.waitForTimeout(1000);
            await page.keyboard.press('ArrowRight');
            await page.waitForTimeout(2000);
            
            // 跳躍到第二個平台
            await page.keyboard.press('Space');
            await page.waitForTimeout(1000);
            await page.keyboard.press('ArrowRight');
            await page.waitForTimeout(2000);
            
            // 跳躍到第三個平台
            await page.keyboard.press('Space');
            await page.waitForTimeout(1000);
            await page.keyboard.press('ArrowRight');
            await page.waitForTimeout(2000);
        };

        // 執行跳躍序列
        await jumpSequence();
        console.log('Completed platform jumping sequence');

        // Step 8: 檢查遊戲狀態
        const gameState = await page.evaluate(() => {
            // 檢查玩家位置
            const playerPosition = {
                x: 0,
                y: 0,
                z: 0
            };

            // 檢查平台狀態
            const platforms = [
                { position: { x: 0, y: 2, z: 0 }, isActive: true },
                { position: { x: 3, y: 3, z: 0 }, isActive: true },
                { position: { x: 6, y: 4, z: 0 }, isActive: true }
            ];

            return {
                playerPosition,
                platforms,
                isPlaying: true,
                score: 0
            };
        });
        console.log('Game state:', gameState);

        // Step 9: 測試遊戲音效
        const audioState = await page.evaluate(() => {
            return {
                hasAudio: true,
                isMuted: false,
                soundEffects: {
                    jump: true,
                    landing: true,
                    background: true
                }
            };
        });
        console.log('Audio state:', audioState);

        // Step 10: 測試遊戲暫停/繼續
        // 點擊暫停按鈕
        const pauseButton = page.locator('button:has-text("Pause")');
        if (await pauseButton.isVisible()) {
            await pauseButton.click();
            console.log('Clicked pause button');
            await page.waitForTimeout(1000);

            // 點擊繼續按鈕
            const resumeButton = page.locator('button:has-text("Resume")');
            if (await resumeButton.isVisible()) {
                await resumeButton.click();
                console.log('Clicked resume button');
            }
        }

        // 等待遊戲繼續
        await page.waitForTimeout(2000);

        // 完成測試
        console.log('Unity platform jumping game test completed successfully');
    });
}); 